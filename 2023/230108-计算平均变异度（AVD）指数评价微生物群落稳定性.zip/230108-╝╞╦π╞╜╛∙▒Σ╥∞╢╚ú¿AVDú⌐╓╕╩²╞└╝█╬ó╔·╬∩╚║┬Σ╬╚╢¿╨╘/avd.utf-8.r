#读取 OTU 丰度表
otu <- read.delim('otu_table.txt', row.names = 1, sep = '\t', check.names = FALSE)

#计算各 OTU 的变异度
ai <- abs(otu-apply(otu, 1, mean))/apply(otu, 1, sd)

#由于此时计算的是单个样本的 AVD，即 k=1
avd <- colSums(ai)/(1*nrow(otu))

#读取分组，合并数据并简单可视化
group <- read.delim('group.txt', sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)
group$AVD <- avd
group

library(ggpubr)

ggboxplot(group, x = 'group', y = 'AVD', fill = 'group', 
    color = 'gray30', width = 0.6, size = 1, legend = 'right') +
scale_fill_manual(values = c('#E7B800', '#00AFBB')) +
labs(x = '', y = 'AVD', fill = '')

