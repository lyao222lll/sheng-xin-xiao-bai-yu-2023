#读取示例数据
dat <- read.delim('taxonomy.txt')

#使用 ggtern 包的方法绘制一个三元图来展示 3 个生物类群在各站点的丰度分布
#在这个示例中，将环境变量赋值为点的颜色，来展现各站点的环境梯度
library(ggtern)

ggtern(dat, aes(tax1, tax2, tax3)) +
geom_point(aes(color = env)) +
scale_color_gradientn(colors = c('#00008F', '#0030FF', '#00EFFF', '#8FFF70', '#FFCF00', '#FF2000', '#8F0000')) +
geom_mask() +
theme_rgbw() + 
theme(axis.text = element_blank(), axis.ticks = element_blank()) +
labs(x = 'Tax 1', y = 'Tax 2', z = 'Tax 3', color = 'Environment')

#使用函数 stat_interpolate_tern() 拟合各站点的环境梯度
ggtern(dat, aes(tax1, tax2, tax3)) +
stat_interpolate_tern(geom = 'polygon', method = lm, aes(value = env, fill = ..level..), expand = 1) +
#stat_interpolate_tern(geom = 'polygon', method = mgcv::gam, aes(value = env, fill = ..level..), expand = 1) +
#stat_interpolate_tern(geom = 'polygon', method = loess, aes(value = env, fill = ..level..), expand = 1) +
scale_fill_gradientn(colors = c('#00008F', '#0030FF', '#00EFFF', '#8FFF70', '#FFCF00', '#FF2000', '#8F0000')) +
geom_point() +
geom_mask() +
theme_rgbw() + 
theme(axis.text = element_blank(), axis.ticks = element_blank()) +
labs(x = 'Tax 1', y = 'Tax 2', z = 'Tax 3', fill = 'Environment')

#使用函数 scale_color_gradientn() 拟合各站点的环境梯度
library(ggtern)

p <- ggtern(dat, aes(tax1, tax2, tax3)) +
geom_mask() +
theme_rgbw() + 
#geom_smooth_tern() +
theme(axis.text = element_blank(), axis.ticks = element_blank()) +
labs(x = 'Tax 1', y = 'Tax 2', z = 'Tax 3', color = 'Environment')

#拟合环境梯度的等密度线
p +
geom_interpolate_tern(aes(value = env, color = ..level..), bins = 100) +
scale_color_gradientn(colors = c('#00008F', '#0030FF', '#00EFFF', '#8FFF70', '#FFCF00', '#FF2000', '#8F0000')) +
geom_point()

#拟合环境梯度的填充曲线
#网上的教程中有这方法，不知怎的我这里画不出来图，可能是 R 或 ggtern 包版本的问题
p + 
geom_interpolate_tern(aes(value = env, fill = ..level..), bins = 100) +
scale_fill_gradientn(colors = c('#00008F', '#0030FF', '#00EFFF', '#8FFF70', '#FFCF00', '#FF2000', '#8F0000')) +
geom_point()


