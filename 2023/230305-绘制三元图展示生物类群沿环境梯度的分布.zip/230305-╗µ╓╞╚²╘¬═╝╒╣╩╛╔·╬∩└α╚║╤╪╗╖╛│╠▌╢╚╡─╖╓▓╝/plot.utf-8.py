#读取数据
#因为我不会 python 的矩阵操作，因此用的 open() 函数按行读取，并将各变量存为列表
tax1 = []
tax2 = []
tax3 = []
env = []

taxonomy = open('taxonomy.txt', 'r')
taxonomy.readline()
for line in taxonomy:
    line = line.strip().split('\t')
    tax1.append(float(line[1]))
    tax2.append(float(line[2]))
    tax3.append(float(line[3]))
    env.append(float(line[4]))

taxonomy.close()

##绘制三元图来展示 3 个生物类群在各站点的丰度分布
import skimage as create_ternary_contour
import plotly.figure_factory as ff
import numpy as np

tax1 = np.array(tax1)
tax2 = np.array(tax2)
tax3 = np.array(tax3)
env = np.array(env)

#拟合环境梯度的等密度线
fig = ff.create_ternary_contour(
    np.array([tax2, tax1, tax3]), 
    env,
    pole_labels = ['Tax 2', 'Tax 1', 'Tax 3'],
    ncontours = 30,
    coloring = 'lines',
    colorscale='Viridis', 
    showmarkers = True, 
    showscale = True 
)

fig.show()

#拟合环境梯度的填充曲线
fig = ff.create_ternary_contour(
    np.array([tax2, tax1, tax3]), 
    env,
    pole_labels = ['Tax 2', 'Tax 1', 'Tax 3'],
    interp_mode = 'cartesian', 
    ncontours = 30,
    colorscale='Viridis', 
    showscale = True 
)

fig.show()



