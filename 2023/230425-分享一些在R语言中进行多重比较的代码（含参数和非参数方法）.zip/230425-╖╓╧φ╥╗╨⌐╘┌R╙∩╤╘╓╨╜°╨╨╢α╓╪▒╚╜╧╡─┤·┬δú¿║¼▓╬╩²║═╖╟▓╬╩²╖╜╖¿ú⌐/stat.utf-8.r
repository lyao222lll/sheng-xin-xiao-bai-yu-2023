#读取 circAnks1a 的 qPCR 定量数据
circAnks1a <- read.delim('circAnks1a_qPCR.txt', stringsAsFactors = FALSE)
circAnks1a

#预定义因子水平，也就是给分组按时间排个序
circAnks1a$Group <- factor(circAnks1a$Group, levels = c('Sham', 'SNL 3d', 'Day 7d', 'Day 10d', 'Day 14d'))
circAnks1a$Group

#可简单绘制箱线图查看数据情况
library(ggplot2)

ggplot(circAnks1a, aes(Group, Relative_expression)) +
geom_boxplot(fill = 'gray') +
theme(panel.grid = element_blank(), panel.background = element_blank(), 
	axis.line = element_line(color = 'black'), 
	axis.ticks = element_line(color = 'black'),
	axis.text = element_text(color = 'black')) +
labs(x = '', y = 'Relative expression')


#本示例试图通过方差分析比较 circAnks1a 在各时间点的表达差异

#正态性或方差齐性检验来评价数据是否可以适用于方差分析
car::qqPlot(lm(Relative_expression~Group, data = circAnks1a), simulate = TRUE, main = 'QQ Plot', labels = FALSE)
bartlett.test(Relative_expression~Group, data = circAnks1a)

#本示例上述条件均满足不再多说，单因素方差分析（One Way ANOVA）比较 circAnks1a 在各时间点的表达差异
fit <- aov(Relative_expression~Group, data = circAnks1a)
summary(fit)

#对于 ANOVA 外的其他常见的参数检验方法（这些方法均可继承后续的多重比较）
#fit <- lm(Relative_expression~Group, data = circAnks1a)  #线性模型（结果同 ANOVA）
#fit <- glm(Relative_expression~Group, data = circAnks1a, family = 'gaussian')  #广义线性模型（除正态数据外，如果是其他分布的情形，在 family 中更改）
#fit <- lme(Relative_expression~Group, random = ~1lrandom, data = circAnks1a)  #混合线性模型（如想纳入随机效应的话，在 random 中指定随机效应）

#如下列出了几种多重比较的方法
#各方法的原理本篇不介绍，有兴趣可自行了解

#多重比较 - Tukey's all-pair comparisons
library(multcomp)

tuk <- cld(glht(fit, alternative = 'two.sided', linfct = mcp(Group = 'Tukey')), decreasing = TRUE)
tuk
plot(tuk)

#多重比较 - Dunnett’s Correction
DunnettTest(circAnks1a$Relative_expression, circAnks1a$Group)
dunnet <- glht(fit, linfct = mcp(Group = 'Dunnett'))
plot(dunnet)

#多重比较 - Fisher’s Least Significant Difference (LSD)
library(agricolae)

lsd <- LSD.test(fit, trt = 'Group', p.adj = 'BH')
lsd
plot(lsd)

#多重比较 - Scheffe test (薛费检验)
library(DescTools)

sf <- ScheffeTest(fit)
sf
par(las = 1)
plot(sf)

#多重比较 - Stdent-Newman-Keuls test (SNK，纽曼-科伊尔斯检验)
library(PMCMRplus)

snk <- snkTest(fit)
summaryGroup(snk)
plot(snk)

#######非参数检验，以 Kruskal Wallis test 为例
fit <- kruskal.test(Relative_expression~Group, circAnks1a)
fit

#Wilcoxon Rank Sum Tests 进行两两比较
pairwise.wilcox.test(circAnks1a$Relative_expression, circAnks1a$Group)
source('http://www.statmethods.net/RiA/wmc.txt')
wmc(Relative_expression~Group, data = circAnks1a)

#Post hoc test is using the criterium Fisher's least significant difference
library(agricolae)

kw <- kruskal(circAnks1a$Relative_expression, circAnks1a$Group, p.adj = 'BH')
kw
plot(kw)




