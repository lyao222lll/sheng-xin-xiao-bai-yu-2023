library(pheatmap)

#读取数据
dat <- read.table('gene_FPKM.top30.txt', sep = '\t', row.names = 1, header = TRUE, check.names = FALSE)

#添加样本分组
annotation_col1 = data.frame(
    Group = c('control', 'control', 'control', 'treat', 'treat', 'treat'),
    row.names = colnames(dat)
)

#绘制基因表达热图
#以下仅列举简单参数，关于颜色、字体等的详细参数等参阅帮助 ?pheatmap
pheatmap(
    dat, 
	scale = 'row',  #基因表达值按行标准化
    cluster_rows = TRUE, cluster_cols = TRUE,  #行列是否聚类
    fontsize_row = 8, fontsize_col = 8,  #字体大小设置
    color = colorRampPalette(c('green', 'black', 'red'))(50),  #热图颜色设置，本示例由绿到红渐变表示表达值增加
    annotation_col = annotation_col1,  #定义样本分组
    cellwidth = 25, cellheight = 8, border_color = NA  #格子宽度高度等设置
)

### 基因太多时，可以隐藏基因名称
library(pheatmap)

#读取数据
dat <- read.table('gene_FPKM.all.txt', sep = '\t', row.names = 1, header = TRUE, check.names = FALSE)

#添加样本分组
annotation_col1 = data.frame(
    Group = c('control', 'control', 'control', 'treat', 'treat', 'treat'),
    row.names = colnames(dat)
)

#绘制基因表达热图
#同上，有关颜色、字体等参数详情 ?pheatmap
pheatmap(
    dat, 
    scale = 'row', 
    fontsize_col = 8, show_rownames = FALSE, 
    cluster_rows = TRUE, cluster_cols = TRUE,
    color = colorRampPalette(c('green', 'black', 'red'))(100), 
    annotation_col = annotation_col1, 
    cellwidth = 25, cellheight = 0.07, border_color = NA
)


### 基因太多了，只将重要的少数基因在热图中标注出名称

library(ComplexHeatmap)

#表达矩阵，考虑到ComplexHeatmap没有scale参数，因此需事先手动做个行标准化
mat <- read.delim('gene.txt', row.names = 1, check.names = FALSE)
for (i in 1:nrow(mat)) mat[i, ] <- scale(log(unlist(mat[i, ]) + 1, 2))
mat <- as.matrix(mat)

#定义样本分组，例如示例文件中共 A、B、C 3组
samples <- rep(c('A', 'B', 'C'), c(3, 3, 3))	

#先绘制一个不显示任何基因名称的热图
heat <- Heatmap(mat, 
    col = colorRampPalette(c('green', 'black', 'red'))(100), #定义热图由低值到高值的渐变颜色
    heatmap_legend_param = list(grid_height = unit(10,'mm')),  #图例高度设置
	show_row_names = FALSE,  #不展示基因名称
    top_annotation = HeatmapAnnotation(Group = samples, 
        simple_anno_size = unit(2, 'mm'), 
        col = list(Group = c('A' = '#00DAE0', 'B' = '#FF9289', 'C' = 'blue')),  #定义样本分组的颜色
        show_annotation_name = FALSE), 
    column_names_gp = gpar(fontsize = 10), row_names_gp = gpar(fontsize = 6))  #字体大小

heat

#读取待展示的基因名称，并添加到热图中
name <- read.delim('name.txt', header = FALSE, check.names = FALSE)
heat + rowAnnotation(link = anno_mark(at = which(rownames(mat) %in% name$V1), 
    labels = name$V1, labels_gp = gpar(fontsize = 10)))

### 2个样品时，无需按行标准化
library(pheatmap)

#读取数据
dat <- read.table('gene_FPKM.2sample.txt', sep = '\t', row.names = 1, header = TRUE, check.names = FALSE)

#热图绘制，仅两个样本时去掉 scale = 'row'
#同上，其他有关颜色、字体等参数详情 ?pheatmap
pheatmap(
    dat, 
    fontsize_row = 8, fontsize_col = 8, 
    cluster_rows = TRUE, cluster_cols = TRUE,
    color = colorRampPalette(c('green', 'black', 'red'))(30), 
    cellwidth = 20, cellheight = 10, border_color = NA
)

#如果还像先前那样带着 scale = 'row' 就没有意义了，例如
pheatmap(
    dat, 
    scale = 'row',
    fontsize_row = 8, fontsize_col = 8, 
    cluster_rows = TRUE, cluster_cols = TRUE,
    color = colorRampPalette(c('green', 'black', 'red'))(30), 
    cellwidth = 20, cellheight = 10, border_color = NA
)

