#读取海表温度的作图数据
dat <- read.delim('sst.txt', sep = '\t')

#使用 ggplot2 的方法绘制一个带分面的地图展示 12 个月的海表温度
library(ggplot2)

p <- ggplot() +
geom_polygon(data = map_data('world'), aes(x = long, y = lat, group = group), fill = 'gray80') +  #绘制地图
scale_x_continuous(breaks = c(-180, -90, 0, 90, 180), expand = c(0, 0), labels = c('180°W', '90°W', '0', '90°E', '180°E')) +
scale_y_continuous(breaks = c(-60, -30, 0, 30, 60), expand = c(0, 0), labels = c('60°S', '30°S', '0', '30°N', '60°N')) +
geom_tile(data = dat, aes(x = lon, y = lat, fill = sst)) +  #以热图可视化海洋网格温度
scale_fill_gradientn(colors = c('#3235A4', '#21B1A6', '#FEF70F'), limits = c(-2, 32)) +
facet_wrap(~month, ncol = 4) +  #12 个月的分面
theme_bw() + 
theme(panel.grid.minor = element_blank(), legend.background = element_blank()) +
labs(x = 'Longitude', y = 'Latitude') 

p

#使用 gganimate 和 gapminder 包的方法绘制动态图
library(ggplot2)
library(metR)
library(gganimate)
library(gapminder)

p <- ggplot() +
geom_polygon(data = map_data('world'), aes(x = long, y = lat, group = group), fill = 'gray80') +  #绘制地图
scale_x_continuous(breaks = c(-180, -90, 0, 90, 180), expand = c(0, 0), labels = c('180°W', '90°W', '0', '90°E', '180°E')) +
scale_y_continuous(breaks = c(-60, -30, 0, 30, 60), expand = c(0, 0), labels = c('60°S', '30°S', '0', '30°N', '60°N')) +
geom_contour_fill(data = dat, aes(x = lon, y = lat, z = sst, fill = ..level..), binwidth = 1, show.legend = FALSE) +  #热图在动图中出现了问题，于是绘制为温度梯度的等密度线（使用到 metR 包）
stat_contour(data = dat, aes(x = lon, y = lat, z = sst, color = ..level..)) +
scale_fill_divergent_discretised(low = '#3235A4', mid = '#21B1A6', high = '#FEF70F', limits = c(-2, 32), midpoint = 15) +
scale_colour_gradient2(low = '#3235A4', mid = '#21B1A6', high = '#FEF70F', limits = c(-2, 32), midpoint = 15) +
theme_bw() + 
theme(panel.grid.minor = element_blank(), legend.background = element_blank()) +
transition_manual(month) +  #按 12 个月分别播放动图
labs(title = 'Month: {current_frame}', x = 'Longitude', y = 'Latitude', color = 'SST')

p

