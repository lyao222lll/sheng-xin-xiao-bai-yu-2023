#读取功能富集分析结果数据
term <- read.delim('term.txt')

#绘制散点图可视化功能富集结果，同时包含上下调信息
library(ggplot2)
library(ggrepel)

p <- ggplot(data = term, aes(x = RichFactor, y = -log10(PValue))) +
geom_point(aes(color = group, fill = group), size = 2, shape = 21) +
geom_text_repel(aes(label = Term, color = group,), size = 3, box.padding = unit(0.5, 'lines'), show.legend = FALSE) + 
scale_color_manual(values = c('#0C9348', '#50B74E', '#C42634', '#EE6036')) +
scale_fill_manual(values = c('#8DC549', '#D7DD3B', '#ED413D', '#F5EC48')) +
theme(panel.grid = element_blank(), 
    panel.background = element_rect(fill = 'gray90'),
    axis.line = element_line(color = 'black'), 
    axis.ticks = element_line(color = 'black', size = 0.5), 
    axis.text = element_text(color = 'black', size = 9), 
    legend.position = 'none') +
geom_vline(xintercept = 0, color = 'gray', size = 0.5, linetype = 2) +
labs(x = 'Rich Factor', y = '-Log10 PValue')

p

#为了减少点的拥挤或者避免那些特别显著的点导致的“离群”，可以使用截断坐标轴来展示

#视情况截取坐标
p1 <- p + 
scale_y_continuous(limits = c(0, 8), expand = c(0, 0))

p2 <- p +
scale_y_continuous(limits =  c(19, 21), expand = c(0, 0)) +
theme(axis.text.x = element_blank(),
    axis.ticks.x = element_blank(), 
    axis.line.x = element_blank()) +
labs(x = '', y = '')

#使用 patchwork 包组图
library(patchwork)

p2 + p1 + plot_layout(ncol = 1, heights = c(1, 3))

#注：我没有用 ggbreak、gg.gap 等方法直接绘制截断坐标轴是有原因的，因为它们与 ggrepel 不兼容
#不信的话大家自己试试就知道了，例如：
#library(ggbreak)
#p +  scale_y_break(breaks = c(8, 19))
