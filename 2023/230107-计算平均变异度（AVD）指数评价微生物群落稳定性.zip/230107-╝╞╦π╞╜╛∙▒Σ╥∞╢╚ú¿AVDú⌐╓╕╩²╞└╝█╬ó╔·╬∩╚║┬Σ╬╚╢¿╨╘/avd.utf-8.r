#定义公式计算 OTU 的变异度和 AVD
#注：otu_group 代表了一组抽平后的 OTU 丰度表（多组需事先拆分，且需提前剔除所有值均为 0 的行）
ai <- function(otu_group) abs(otu_group-apply(otu_group, 1, mean))/apply(otu_group, 1, sd)
avd <- function(otu_group) colSums(ai(otu_group))/(ncol(otu_group)*nrow(otu_group))

#读取 OTU 丰度表和样本分组
otu <- read.delim('otu_table.txt', row.names = 1, sep = '\t', check.names = FALSE)
group <- read.delim('group.txt', sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)

#计算各组样本的 AVD
AVD <- NULL
for (k in unique(group$group)) {
	group_k <- group[which(group$group == k), ]
	otu_group_k <- otu[group_k$sample]
	otu_group_k <- otu_group_k[which(rowSums(otu_group_k)>0),]
	group_k$AVD <- avd(otu_group_k)
	AVD <- rbind(AVD, group_k)
}
AVD

#简单可视化
library(ggpubr)

ggboxplot(AVD, x = 'group', y = 'AVD', fill = 'group', 
    color = 'gray30', width = 0.6, size = 1, legend = 'right') +
scale_fill_manual(values = c('#E7B800', '#00AFBB')) +
labs(x = '', y = 'AVD', fill = '')

