library(ComplexHeatmap)

#读取基因表达矩阵
#为了后续绘制热图时体现各基因在不同分组样本之间的表达差异，手动进行行标准化（先 log(+1) 再 scale）
mat <- read.delim('gene_express.txt', row.names = 1, check.names = FALSE)
for (i in 1:nrow(mat)) mat[i, ] <- scale(log(unlist(mat[i, ]) + 1, 2))
mat <- as.matrix(mat)

#读取样本分组和基因分组矩阵
sample_group <- as.matrix(read.delim('sample_group.txt', row.names = 1))
gene_anno <- as.matrix(read.delim('gene_anno.txt', row.names = 1))

#绘制默认的聚类热图
Heatmap(
    mat, name = 'gene_express', 
    col = colorRampPalette(c('#240EFF', '#B491F9', '#ECEAEF', '#FFA48C', '#FF1A09'))(100),  #基因表达的渐变色设置
    cluster_rows = TRUE, cluster_columns = TRUE,  #行列根据基因表达聚类
    row_names_gp = gpar(fontsize = 8), column_names_gp = gpar(fontsize = 10),  #行（基因名）列（样本名）字体大小
    
    #根据基因类型定义行的颜色
    right_annotation = HeatmapAnnotation(
        Class = gene_anno, which = 'row', show_annotation_name = FALSE, 
        col = list(Class= c('Carbohydrate metabolism' = '#FFAD30', 'Lipid metabolism' = '#634FB8', 'Amino acid metabolism' = '#68AD30'))
    ),
    
    #根据样本分组定义列的颜色
    top_annotation = HeatmapAnnotation(
        Group = sample_group, which = 'column', show_annotation_name = FALSE, 
        col = list(Group = c('A' = '#00DAE0', 'B' = '#FF9289', 'C' = '#339AFC'))
    )
)

#绘制根据基因类型和样本分组对行列进行排序后的聚类热图
Heatmap(
    mat, name = 'gene_express', 
    col = colorRampPalette(c('#240EFF', '#B491F9', '#ECEAEF', '#FFA48C', '#FF1A09'))(100),  #基因表达的渐变色设置
    cluster_rows = TRUE, cluster_columns = TRUE,  #行列根据基因表达聚类
    row_names_gp = gpar(fontsize = 8), column_names_gp = gpar(fontsize = 10),  #行（基因名）列（样本名）字体大小
    row_split = gene_anno, column_split = sample_group,  #行根据基因类型、列根据样本分组进行排序（强制聚类）
    row_title_gp = gpar(fontsize = 10), column_title_gp = gpar(fontsize = 10),  #行（基因类型）列（样本分组）字体大小
    
    #根据基因类型定义行的颜色
    right_annotation = HeatmapAnnotation(
        Class = gene_anno, which = 'row', show_annotation_name = FALSE, 
        col = list(Class= c('Carbohydrate metabolism' = '#FFAD30', 'Lipid metabolism' = '#634FB8', 'Amino acid metabolism' = '#68AD30'))
    ),
    
    #根据样本分组定义列的颜色
    top_annotation = HeatmapAnnotation(
        Group = sample_group, which = 'column', show_annotation_name = FALSE, 
        col = list(Group = c('A' = '#00DAE0', 'B' = '#FF9289', 'C' = '#339AFC'))
    )
)

