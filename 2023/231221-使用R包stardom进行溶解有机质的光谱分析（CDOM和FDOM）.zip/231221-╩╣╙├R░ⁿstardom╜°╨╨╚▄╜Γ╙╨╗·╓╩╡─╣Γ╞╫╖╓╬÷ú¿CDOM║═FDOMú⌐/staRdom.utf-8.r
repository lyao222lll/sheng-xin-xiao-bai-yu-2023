#安装 staRdom 包
#devtools::install_github('MatthiasPucher/staRdom')

#加载 staRdom 包
library(staRdom)

#可以设置并行处理
cores <- detectCores(logical = FALSE)


####CDOM 数据处理

#读取 CDOM 吸光度数据（需要提前扣除纯水样的吸光度）
absorbance <- read.csv('absorbance.csv')

#吸光度基线校正（本示例减去 680-700nm 波长吸光度的平均值）
#注：也可以使用 700-800nm 波长吸光度的平均值，不同文献中有不同的取值方法，可以更改
absorbance <- abs_blcor(absorbance, wlrange = c(680, 700))

#吸收系数、光谱斜率等的计算
#参数 cuvl 用于指定测样时的光程，本示例 cuvl=5 即使用的 5cm 比色皿测量的吸光度
slope_parms <- abs_parms(absorbance, cuvl = 5, cores = cores)
slope_parms

#输出
#write.csv(slope_parms, 'CDOM.csv', quote = FALSE, row.names = FALSE)

####FDOM 数据处理

#读取 FDOM 荧光数据
eem_list <- eem_read('EEMs/', recursive = TRUE, import_function = eem_csv)

summary(eem_list)  #查看样品概述
eem_overview_plot(eem_list, spp = 9, contour = TRUE)  #绘制样品的荧光光谱

#扣除纯水的荧光（即扣除空白）
#纯水样的 EEMs 数据文件需要以“nano”、“miliq”、“milliq”、“mq”、“blank”等命名方便自动识别
eem_list <- eem_extend2largest(eem_list, interpolation = 1, extend = FALSE, cores = cores)
eem_list <- eem_remove_blank(eem_list)

#使用测量 CDOM 时的吸光度数据校正内滤光效应（IFE）
#参数 cuvl 用于指定 CDOM 测样时的光程，本示例 cuvl=5 即使用的 5cm 比色皿测量的吸光度
eem_list <- eem_ife_correction(eem_list, absorbance, cuvl = 5)
eem_overview_plot(eem_list, spp = 9, contour = TRUE)  #绘制样品的荧光光谱

#拉曼归一化
eem_list <- eem_raman_normalisation2(eem_list, blank = 'blank')

#从样品集中删除纯水的空白样品
#纯水样的 EEMs 数据文件需要以“nano”、“miliq”、“milliq”、“mq”、“blank”等命名方便自动识别
eem_list <- eem_extract(eem_list, c('nano', 'miliq', 'milliq', 'mq', 'blank'), ignore_case = TRUE)
absorbance <- dplyr::select(absorbance, -matches('nano|miliq|milliq|mq|blank', ignore.case = TRUE))
eem_overview_plot(eem_list, spp = 9, contour = TRUE)  #绘制样品的荧光光谱

#去除散射
remove_scatter <- c(TRUE, TRUE, TRUE, TRUE)
remove_scatter_width <- c(15, 15, 15, 15)
eem_list <- eem_rem_scat(eem_list, remove_scatter = remove_scatter, remove_scatter_width = remove_scatter_width)
eem_overview_plot(eem_list, spp = 9, contour = TRUE)  #绘制样品的荧光光谱

#插值散射，几种插值方法详见 ?eem_interp
eem_list <- eem_interp(eem_list, cores = cores, type = 1, extend = FALSE)
eem_overview_plot(eem_list, spp = 9, contour = TRUE)  #绘制样品的荧光光谱

#读取样品稀释信息根据稀释倍数进行校正
meta <- read.csv('metatable.csv')
dil_data <- meta['dilution']
eem_list <- eem_dilution(eem_list, dil_data)

#平滑数据（如果使用寻峰法，推荐使用；如果使用平行因子法，忽略该步骤）
#参数 n 用于指定移动平均窗口大小
eem4peaks <- eem_smooth(eem_list, n = 4, cores = cores)
eem_overview_plot(eem_list, spp = 9, contour = TRUE)  #绘制样品的荧光光谱

summary(eem_list)  #查看样品概述

#根据文献中报道的峰值选取和指数
coble_peaks <- eem_coble_peaks(eem4peaks)
FI <- eem_fluorescence_index(eem4peaks)
HIX <- eem_humification_index(eem4peaks, scale = TRUE)
BIX <- eem_biological_index(eem4peaks)

indices_peaks <- cbind(coble_peaks, FI['fi'], HIX['hix'], BIX['bix'])
indices_peaks

#输出
#write.csv(indices_peaks, 'FDOM.csv', quote = FALSE, row.names = FALSE)

#合并输出
#slope_parms <- cbind(slope_parms, indices_peaks[-1])
#slope_parms
#write.csv(slope_parms, 'CDOM_FDOM.csv', quote = FALSE, row.names = FALSE)
