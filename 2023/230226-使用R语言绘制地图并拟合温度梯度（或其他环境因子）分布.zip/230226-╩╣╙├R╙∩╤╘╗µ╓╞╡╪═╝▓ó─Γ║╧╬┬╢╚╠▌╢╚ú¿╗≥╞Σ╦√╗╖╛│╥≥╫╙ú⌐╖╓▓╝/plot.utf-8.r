library(ggplot2)

#读取示例的海表温度数据
sst <- read.delim('sst.txt', sep = '\t')

#首先使用 ggplot2 的方法绘制一个地图
p <- ggplot() +
geom_polygon(data = map_data('world'), aes(x = long, y = lat, group = group), fill = 'gray80') +  #绘制地图
theme_bw() + 
theme(panel.grid.minor = element_blank(), legend.background = element_blank()) +
scale_x_continuous(breaks = c(-150, -100, -50, 0, 50, 100, 150), expand = c(0, 0), 
    labels = c('150°W', '100°W', '50°W', '0', '50°E', '100°E', '150°E')) +
scale_y_continuous(breaks = c(-60, -30, 0, 30, 60), expand = c(0, 0), 
    labels = c('60°S', '30°S', '0', '30°N', '60°N')) +
labs(x = 'Longitude', y = 'Latitude')

p

#在高分辨率的情况下，可以直接使用 geom_point()、geom_tile() 等来展示每个站点或网格的温度数值
#其中经纬度用于定位，并将各海区的海表温度映射为图中点的颜色
p +
geom_point(data = sst, aes(x = lon, y = lat, color = SST), size = 0.1) +
scale_color_gradientn(colors = c('#3235A4', '#21B1A6', '#FEF70F'), limits = c(-2, 32))

p +
geom_tile(data = sst, aes(x = lon, y = lat, fill = SST)) +
scale_fill_gradientn(colors = c('#3235A4', '#21B1A6', '#FEF70F'), limits = c(-2, 32))


#如果是低分辨率的数据，或者记录温度的站点是非均匀分布的，以及很多缺失值等，无法使用上述点图或热图来展示（通常效果会糟糕）
#可以使用 metR 包的方法，使用曲线拟合温度的数值，在图中添加温度梯度曲线
library(metR)

#展示为温度梯度的等密度线，详情 ?stat_contour
p +
stat_contour(data = sst, aes(x = lon, y = lat, z = SST, color = ..level..), bins = 30) +
geom_text_contour(data = sst, aes(x = lon, y = lat, z = SST, color = ..level..), size = 2.5) +
scale_color_gradientn(colors = c('#3235A4', '#21B1A6', '#FEF70F'), limits = c(-2, 32)) 

#展示为温度梯度的填充曲线，详情 ?geom_contour_fill
p +
geom_contour_fill(data = sst, aes(x = lon, y = lat, z = SST, fill = ..level..), binwidth = 1) +
scale_fill_divergent_discretised(low = '#3235A4', mid = '#21B1A6', high = '#FEF70F', limits = c(-2, 32), midpoint = 15)

