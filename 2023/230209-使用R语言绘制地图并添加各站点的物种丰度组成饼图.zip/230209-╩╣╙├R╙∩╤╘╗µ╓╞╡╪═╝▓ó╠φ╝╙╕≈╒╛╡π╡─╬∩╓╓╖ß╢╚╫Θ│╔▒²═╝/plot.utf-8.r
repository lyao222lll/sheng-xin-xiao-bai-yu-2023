library(ggplot2)
library(scatterpie)

#首先加载地图包绘制地图底板（本示例使用了一个世界地图）
map <- map_data('world')

#绘制地图
p <- ggplot() +
geom_polygon(data = map, aes(x = long, y = lat, group = group), fill = 'gray80') +  #绘制地图
theme_bw() + 
theme(panel.grid.minor = element_blank(), legend.background = element_blank()) +
scale_x_continuous(breaks = c(-150, -100, -50, 0, 50, 100, 150), expand = c(0, 0), 
    labels = c('150°W', '100°W', '50°W', '0', '50°E', '100°E', '150°E')) +
scale_y_continuous(breaks = c(-60, -30, 0, 30, 60), expand = c(0, 0), 
    labels = c('60°S', '30°S', '0', '30°N', '60°N'))

p

#然后读取作图数据，并绘制各站点的物种丰度饼图并映射在地图中，详情 ?geom_scatterpie
dat <- read.delim('species.txt', sep = '\t')
dat <- reshape2::melt(dat, id = c('region', 'long', 'lat', 'total'))

p + 
geom_scatterpie(data = dat, aes(x = long, y = lat, group = region, r = total), cols = 'variable', long_format = TRUE) +  #映射物种丰度饼图
scale_fill_manual(limits = c('species1', 'species2', 'species3', 'species4', 'species5', 'species6', 'species7'), 
    values = c('#9FCBE2', '#2D83BE', '#B3E08B', '#2FA128', '#FF8000', '#E41316', '#6A3A9B')) +  #分配各物种颜色
geom_scatterpie_legend(dat$total, x = 160, y = -60) +  #有关饼图大小的图例，饼图大小代表总丰度
labs(x = 'Longitude', y = 'Latitude', fill = 'species')
